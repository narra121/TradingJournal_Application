// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyCfBObyqFWkzFk2-bs8OAyP85DyozYi3XM",
  authDomain: "tradejournal-b044f.firebaseapp.com",
  projectId: "tradejournal-b044f",
  storageBucket: "tradejournal-b044f.firebasestorage.app",
  messagingSenderId: "189867609018",
  appId: "1:189867609018:web:c7937c5ed1018107a62b83",
};

// Initialize Firebase
// Initialize Firebase
export const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const storage = getStorage(app);
