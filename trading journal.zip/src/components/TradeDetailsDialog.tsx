import { RootState } from "@/app/store";
import { Trade, TradeDetails } from "@/app/traceSlice";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Clock,
  TrendingUp,
  BarChart,
  AlertTriangle,
  DollarSign,
  LineChart,
} from "lucide-react";
import { useSelector } from "react-redux";

interface TradeDetailsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  trade: TradeDetails;
}

export function TradeDetailsDialog({
  isOpen,
  onClose,
  trade,
}: TradeDetailsDialogProps) {
  const tradeData: Trade = useSelector(
    (state: RootState) =>
      state.TradeData.trades.find((t) => t.trade.tradeId === trade.tradeId)!
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[90vw] h-[90vh] p-0 gap-0">
        <div className="grid grid-cols-[1fr,2fr] h-full">
          {/* Left side - Trade Information */}
          <div className="border-r border-border p-6">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold flex items-center gap-2">
                <LineChart className="w-6 h-6 text-primary" />
                {tradeData.trade.symbol} Trade Details
              </DialogTitle>
            </DialogHeader>

            <ScrollArea className="h-[calc(90vh-8rem)] pr-4 mt-6">
              <div className="space-y-8">
                {/* Trade Overview */}
                <div className="bg-card rounded-lg p-6 space-y-4">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <DollarSign className="w-5 h-5 text-primary" />
                    Trade Overview
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">Side</p>
                      <p
                        className={`text-xl font-bold ${
                          tradeData.trade.side === "buy"
                            ? "text-green-500"
                            : "text-red-500"
                        }`}
                      >
                        {tradeData.trade.side.toUpperCase()}
                      </p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">Quantity</p>
                      <p className="text-xl font-bold">{tradeData.trade.qty}</p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">
                        Entry Price
                      </p>
                      <p className="text-xl font-bold">
                        ${tradeData.trade.entry}
                      </p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">
                        Exit Price
                      </p>
                      <p className="text-xl font-bold">
                        ${tradeData.trade.entry}
                      </p>
                    </div>
                    <div className="col-span-2 bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">
                        Profit/Loss
                      </p>
                      <p
                        className={`text-2xl font-bold ${
                          tradeData.trade.pnl >= 0
                            ? "text-green-500"
                            : "text-red-500"
                        }`}
                      >
                        ${tradeData.trade.pnl.toFixed(2)}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Psychology */}
                <div className="bg-card rounded-lg p-6 space-y-4">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <AlertTriangle className="w-5 h-5 text-primary" />
                    Psychology
                  </h3>
                  <div className="space-y-4">
                    <div className="flex gap-2 flex-wrap">
                      {tradeData.psychology.isGreedy && (
                        <span className="bg-yellow-100 text-yellow-800 px-3 py-1.5 rounded-full text-sm font-medium">
                          Greedy Trade
                        </span>
                      )}
                      {tradeData.psychology.isFomo && (
                        <span className="bg-orange-100 text-orange-800 px-3 py-1.5 rounded-full text-sm font-medium">
                          FOMO Trade
                        </span>
                      )}
                      {tradeData.psychology.isRevenge && (
                        <span className="bg-red-100 text-red-800 px-3 py-1.5 rounded-full text-sm font-medium">
                          Revenge Trade
                        </span>
                      )}
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">
                        Emotional State
                      </p>
                      <p className="text-lg font-semibold">
                        {tradeData.psychology.emotionalState}
                      </p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">Notes</p>
                      <p className="text-sm mt-1">
                        {tradeData.psychology.notes}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Analysis */}
                <div className="bg-card rounded-lg p-6 space-y-4">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-primary" />
                    Analysis
                  </h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-muted/50 rounded-lg p-4">
                        <p className="text-sm text-muted-foreground">
                          Risk/Reward Ratio
                        </p>
                        <p className="text-lg font-semibold">
                          {tradeData.analysis.riskRewardRatio}:1
                        </p>
                      </div>
                      <div className="bg-muted/50 rounded-lg p-4">
                        <p className="text-sm text-muted-foreground">
                          Setup Type
                        </p>
                        <p className="text-lg font-semibold">
                          {tradeData.analysis.setupType}
                        </p>
                      </div>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground mb-2">
                        Mistakes
                      </p>
                      <div className="flex gap-2 flex-wrap">
                        {tradeData.analysis.mistakes.map((mistake, index) => (
                          <span
                            key={index}
                            className="bg-red-100 text-red-800 px-3 py-1.5 rounded-full text-sm font-medium"
                          >
                            {mistake}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Metrics */}
                <div className="bg-card rounded-lg p-6 space-y-4">
                  <h3 className="text-lg font-semibold flex items-center gap-2">
                    <BarChart className="w-5 h-5 text-primary" />
                    Metrics
                  </h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">
                        Risk per Trade
                      </p>
                      <p className="text-lg font-semibold">
                        {tradeData.metrics.riskPerTrade}%
                      </p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">
                        Stop Loss Deviation
                      </p>
                      <p className="text-lg font-semibold">
                        {tradeData.metrics.stopLossDeviation}
                      </p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">
                        Target Deviation
                      </p>
                      <p className="text-lg font-semibold">
                        {tradeData.metrics.targetDeviation}
                      </p>
                    </div>
                    <div className="bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">
                        Market Conditions
                      </p>
                      <p className="text-lg font-semibold">
                        {tradeData.metrics.marketConditions}
                      </p>
                    </div>
                    <div className="col-span-2 bg-muted/50 rounded-lg p-4">
                      <p className="text-sm text-muted-foreground">
                        Trading Session
                      </p>
                      <p className="text-lg font-semibold">
                        {tradeData.metrics.tradingSession}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </ScrollArea>
          </div>

          {/* Right side - Images */}
          <ScrollArea className="h-[90vh] bg-muted/30">
            <div className="space-y-6 p-6">
              {tradeData.images.map((image, index) => (
                <div key={index} className="bg-card rounded-lg overflow-hidden">
                  <div className="p-4 bg-muted/50 border-b flex items-center gap-2">
                    <Clock className="w-4 h-4 text-muted-foreground" />
                    <span className="font-medium">
                      {image.timeframe} Timeframe
                    </span>
                  </div>
                  <div className="relative aspect-video">
                    <img
                      src={image.url}
                      alt={`Trade chart ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-4 bg-background">
                    <p className="text-sm text-muted-foreground">
                      {image.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}
